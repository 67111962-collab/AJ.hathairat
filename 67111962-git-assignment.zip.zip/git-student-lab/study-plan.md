# My Study Plan

## 1. Git
Reason: Keep track of project changes.
Practice: ฝึกทำแล็บและ commit งานทุกวัน

## 2. Python
Reason: Build small automation scripts.
Practice: เขียนโปรแกรมรับชื่อแล้วแสดงคำทักทาย

## 3. Computer networks
Reason: Understand how computers communicate.
Practice: ลองจำลองเครือข่ายพื้นฐาน